/**
 * alert-engine.js — Client-side alert trigger engine
 *
 * Evaluates live space weather + local weather data against user alert
 * preferences and fires in-app notifications when thresholds are crossed.
 *
 * ── Architecture ─────────────────────────────────────────────────────────────
 *  1. Listens to 'swpc-update' events (solar wind, Kp, flares, CMEs)
 *  2. Listens to 'cme-propagation-update' events (DBM physics predictions)
 *  3. Polls Open-Meteo every 30 min for user-location weather (temp, cloud, sun)
 *  4. Checks each alert type against user preferences from auth.getAlertPrefs()
 *  5. Applies cooldown to prevent re-firing the same alert type repeatedly
 *  6. Plan-gates: basic tier gets Tier 1 alerts, advanced gets all
 *  7. Writes to Supabase alert_history table (if connected)
 *  8. Dispatches 'user-alert' CustomEvent for the notification bell
 *
 * ── Usage ────────────────────────────────────────────────────────────────────
 *  import { AlertEngine } from './js/alert-engine.js';
 *  const engine = new AlertEngine().start();
 *  window.addEventListener('user-alert', e => showBell(e.detail));
 */

import { auth } from './auth.js';
import { getSupabase, isConfigured } from './supabase-config.js';
import { loadUserLocation } from './user-location.js';
import { listLocations, effectivePrefs, onLocationsChanged } from './saved-locations.js';
import { ConjunctionMonitor } from './conjunction-alert.js';
import { geo, RAD } from './geo/coords.js';

// ── Open-Meteo point forecast (via backend proxy) ───────────────────────────

// Routes through /api/weather/forecast with type=point. Cache dedup means
// a whole-site rollout of alert-engine polling only costs the backend a
// handful of Open-Meteo calls per 15 min, not one per user. See
// api/weather/forecast.js for the full rationale.
const WEATHER_API = '/api/weather/forecast';
const WEATHER_POLL_MS = 30 * 60_000;  // 30 minutes

// Match the proxy's lat/lon quantization so alert-engine's cache keys align
// with trip-planner's — a dashboard open on the same location pre-warms the
// alert-engine's next poll and vice-versa.
const quantize = v => Number((+v).toFixed(3));

/**
 * Fetch point forecast for a lat/lon from the backend proxy.
 * Returns current conditions + today/tomorrow high/low + cloud cover + sunrise/sunset.
 * The proxy's `point` type returns a superset of the fields we need; we
 * just pluck what this module uses.
 *
 * @param {number} lat
 * @param {number} lon
 * @returns {Promise<object|null>}
 */
async function fetchPointWeather(lat, lon) {
    const params = new URLSearchParams({
        type: 'point',
        lat:  String(quantize(lat)),
        lon:  String(quantize(lon)),
        days: '2',
    });
    try {
        const res = await fetch(`${WEATHER_API}?${params}`, {
            signal: AbortSignal.timeout(10000),
        });
        if (!res.ok) return null;
        const data = await res.json();
        if (data.error) return null;
        return {
            temp_f:      data.current?.temperature_2m,
            cloud_cover: data.current?.cloud_cover,        // 0-100%
            is_day:      data.current?.is_day,              // 1 = day, 0 = night
            // Today's forecast
            today_high:  data.daily?.temperature_2m_max?.[0],
            today_low:   data.daily?.temperature_2m_min?.[0],
            sunrise:     data.daily?.sunrise?.[0],          // ISO string
            sunset:      data.daily?.sunset?.[0],
            // Tomorrow's forecast
            tomorrow_high: data.daily?.temperature_2m_max?.[1],
            tomorrow_low:  data.daily?.temperature_2m_min?.[1],
            fetched_at:  Date.now(),
        };
    } catch (e) {
        console.warn('[AlertEngine] Weather fetch failed:', e.message);
        return null;
    }
}

// ── Flare class helpers ──────────────────────────────────────────────────────

const FLARE_ORDER = { A: 0, B: 1, C: 2, M: 3, X: 4 };

function flareClassToLetter(flux) {
    if (flux >= 1e-4) return 'X';
    if (flux >= 1e-5) return 'M';
    if (flux >= 1e-6) return 'C';
    if (flux >= 1e-7) return 'B';
    return 'A';
}

function flareAtOrAbove(currentFlux, threshold) {
    const cur = FLARE_ORDER[flareClassToLetter(currentFlux)] ?? 0;
    const thr = FLARE_ORDER[threshold?.charAt?.(0)?.toUpperCase()] ?? 3;
    return cur >= thr;
}

// ── G-scale from Kp ──────────────────────────────────────────────────────────

function kpToGScale(kp) {
    if (kp >= 9) return 5;
    if (kp >= 8) return 4;
    if (kp >= 7) return 3;
    if (kp >= 6) return 2;
    if (kp >= 5) return 1;
    return 0;
}

// ── R-scale from X-ray flux ──────────────────────────────────────────────────

function fluxToRScale(flux) {
    if (flux >= 2e-3) return 5;
    if (flux >= 1e-3) return 4;
    if (flux >= 1e-4) return 3;
    if (flux >= 5e-5) return 2;
    if (flux >= 1e-5) return 1;
    return 0;
}

function gScaleSeverity(g) {
    if (g >= 4) return 'critical';
    if (g >= 2) return 'warning';
    return 'info';
}

// ── Alert definitions ────────────────────────────────────────────────────────

/**
 * Each alert type has:
 *   key       — matches the notify_* preference field
 *   type      — alert_type enum in alert_history table
 *   tier      — 'basic' or 'advanced' plan requirement
 *   source    — 'swpc' (evaluated on swpc-update) or 'weather' (evaluated on weather poll)
 *   evaluate  — fn(state, prefs, ctx) → { fire, title, body, severity, metadata } | null
 *               ctx = { weather, cmeEvents } — extra data from weather/CME sources
 */
const ALERT_DEFS = [
    // ── Temperature (first alert users configure) ────────────────────────────
    {
        key: 'notify_temperature',
        type: 'storm',  // reuse type; alert_history only has: conjunction|aurora|storm|flare|pass
        tier: 'basic',
        source: 'weather',
        evaluate(_state, prefs, ctx) {
            const w = ctx.weather;
            if (!w) return null;
            const hi = prefs.temp_high_f;
            const lo = prefs.temp_low_f;
            // Check tomorrow's forecast high/low against thresholds
            const forecastHi = w.tomorrow_high ?? w.today_high;
            const forecastLo = w.tomorrow_low  ?? w.today_low;
            const city  = ctx.location?.city  ?? loadUserLocation()?.city ?? 'your location';
            const label = ctx.location?.label ?? city;

            if (hi != null && forecastHi != null && forecastHi >= hi) {
                return {
                    fire: true,
                    title: `High Temperature Alert — ${label}`,
                    body: `Forecast high of ${Math.round(forecastHi)}°F at ${city} exceeds your ${Math.round(hi)}°F threshold.`,
                    severity: forecastHi >= hi + 10 ? 'critical' : 'warning',
                    metadata: { forecast_high: forecastHi, threshold: hi, city, location_id: ctx.location?.id },
                };
            }
            if (lo != null && forecastLo != null && forecastLo <= lo) {
                return {
                    fire: true,
                    title: `Low Temperature Alert — ${label}`,
                    body: `Forecast low of ${Math.round(forecastLo)}°F at ${city} is below your ${Math.round(lo)}°F threshold.`,
                    severity: forecastLo <= lo - 10 ? 'critical' : 'warning',
                    metadata: { forecast_low: forecastLo, threshold: lo, city, location_id: ctx.location?.id },
                };
            }
            return null;
        },
    },

    // ── Aurora — multi-factor (Kp + location + cloud cover + darkness) ───────
    {
        key: 'notify_aurora',
        type: 'aurora',
        tier: 'basic',
        source: 'swpc',
        evaluate(state, prefs, ctx) {
            const kp = state.kp ?? 0;
            const threshold = prefs.aurora_kp_threshold ?? 5;
            if (kp < threshold) return null;

            const loc = ctx.location ?? loadUserLocation() ?? auth.getUser()?.location;
            if (!loc) {
                // No location — fire generic alert
                return {
                    fire: true,
                    title: 'Aurora Alert',
                    body: `Kp ${kp.toFixed(1)} — aurora activity elevated. Set your location for personalized forecasts.`,
                    severity: kp >= 7 ? 'critical' : 'warning',
                    metadata: { kp },
                };
            }

            // Check if aurora oval reaches user's MAGNETIC latitude. Using
            // geo.magneticColatitude (IGRF-2025 dipole) instead of the old
            // `abs(lat) + 3` hack: matters for Reykjavik (high mag lat, lower
            // geo lat) and for southern-hemisphere users whose dipole tilt
            // runs the opposite direction. The boundary constant (72 - Kp·17/9
            // deg) matches js/earth-skin.js:AURORA_FRAG and user-location.js.
            const magCoLatDeg = geo.magneticColatitude({
                lat: loc.lat * (Math.PI / 180),
                lon: loc.lon * (Math.PI / 180),
            }) * RAD;
            const absMagLat = 90 - Math.min(magCoLatDeg, 180 - magCoLatDeg);
            const boundary  = 72 - kp * (17 / 9);
            if (absMagLat < boundary) return null;

            // Multi-factor scoring
            const factors = [];
            let score = 60;  // base: Kp above threshold + oval reaches location

            // Cloud cover factor (from weather data)
            const w = ctx.weather;
            if (w && w.cloud_cover != null) {
                if (w.cloud_cover <= 25) {
                    score += 20;
                    factors.push('clear skies');
                } else if (w.cloud_cover <= 50) {
                    score += 10;
                    factors.push('partly cloudy');
                } else if (w.cloud_cover <= 75) {
                    factors.push('mostly cloudy');
                } else {
                    score -= 15;
                    factors.push('overcast — viewing unlikely');
                }
            }

            // Darkness factor
            if (w && w.is_day != null) {
                if (w.is_day === 0) {
                    score += 15;
                    factors.push('dark sky');
                } else {
                    // Check if sunset is within 2 hours
                    if (w.sunset) {
                        const sunsetMs = new Date(w.sunset).getTime();
                        const hoursToSunset = (sunsetMs - Date.now()) / 3.6e6;
                        if (hoursToSunset > 0 && hoursToSunset <= 2) {
                            score += 5;
                            factors.push(`sunset in ${Math.round(hoursToSunset * 60)}min`);
                        } else {
                            score -= 10;
                            factors.push('still daylight');
                        }
                    }
                }
            }

            // Kp strength bonus
            if (kp >= 7) score += 10;
            if (kp >= 8) score += 10;

            score = Math.max(0, Math.min(100, score));

            const city = loc.city ?? 'your location';
            const label = loc.label ?? city;
            const factorStr = factors.length ? ` (${factors.join(', ')})` : '';

            return {
                fire: true,
                title: `Aurora Alert — ${label} (${score}% visibility)`,
                body: `Kp ${kp.toFixed(1)} — aurora likely visible from ${city}${factorStr}. Look ${loc.lat >= 0 ? 'north' : 'south'} for green/purple curtains.`,
                severity: score >= 75 ? 'critical' : 'warning',
                metadata: { kp, score, cloud_cover: w?.cloud_cover, is_day: w?.is_day, city, location_id: loc.id },
            };
        },
    },

    // ── Geomagnetic Storm ────────────────────────────────────────────────────
    {
        key: 'notify_storm',
        type: 'storm',
        tier: 'basic',
        source: 'swpc',
        evaluate(state, prefs) {
            const kp = state.kp ?? 0;
            const g = kpToGScale(kp);
            const threshold = prefs.storm_g_threshold ?? 1;
            if (g < threshold) return null;
            return {
                fire: true,
                title: `G${g} Geomagnetic Storm`,
                body: `Kp index reached ${kp.toFixed(1)} — G${g} ${g >= 4 ? 'Severe' : g >= 3 ? 'Strong' : g >= 2 ? 'Moderate' : 'Minor'} geomagnetic storm conditions.`,
                severity: gScaleSeverity(g),
                metadata: { kp, g_scale: g },
            };
        },
    },

    // ── Solar Flare ──────────────────────────────────────────────────────────
    {
        key: 'notify_flare',
        type: 'flare',
        tier: 'basic',
        source: 'swpc',
        evaluate(state, prefs) {
            const flux = state.xray_flux ?? 0;
            const threshold = prefs.flare_class_threshold ?? 'M';
            if (!flareAtOrAbove(flux, threshold)) return null;
            const cls = flareClassToLetter(flux);
            return {
                fire: true,
                title: `${cls}-Class Solar Flare`,
                body: `GOES X-ray flux reached ${cls}-class level (${flux.toExponential(1)} W/m²).`,
                severity: cls === 'X' ? 'critical' : cls === 'M' ? 'warning' : 'info',
                metadata: { flux, class: cls },
            };
        },
    },

    // ── CME Earth-Directed (enhanced with DBM propagation) ───────────────────
    {
        key: 'notify_cme',
        type: 'storm',
        tier: 'basic',
        source: 'swpc',
        evaluate(state, _prefs, ctx) {
            const cme = state.earth_directed_cme;
            if (!cme) return null;

            // Try to get enhanced data from CmePropagator (DBM physics)
            const cmeEvents = ctx.cmeEvents ?? [];
            const dbmEvent = cmeEvents.find(e => e.earthDirected && e.hoursUntilArrival() > -6);

            let etaStr, impactStr = '', severity = 'warning';

            if (dbmEvent) {
                // Use physics-based prediction
                const etaH = dbmEvent.hoursUntilArrival();
                etaStr = etaH > 24 ? `${(etaH / 24).toFixed(1)} days` : `${Math.round(etaH)} hours`;
                const impact = dbmEvent.impact;
                if (impact) {
                    impactStr = ` Predicted impact: G${impact.g_scale} ${impact.severity}, Kp ${impact.kp_max?.toFixed(1)}, Dst ${impact.dst_min} nT.`;
                    if (impact.g_scale >= 3) severity = 'critical';
                }
                if (dbmEvent.sheath?.isShock) {
                    impactStr += ` Mach ${dbmEvent.sheath.mach.toFixed(1)} shock.`;
                }
            } else {
                // Fallback to basic ballistic estimate from SWPC feed
                const eta = state.cme_eta_hours;
                etaStr = eta != null
                    ? (eta > 24 ? `${(eta / 24).toFixed(1)} days` : `${Math.round(eta)} hours`)
                    : 'unknown';
                if ((cme.speed ?? 400) > 1000) severity = 'critical';
            }

            return {
                fire: true,
                title: 'Earth-Directed CME',
                body: `A coronal mass ejection is heading toward Earth. Speed: ${cme.speed ?? '?'} km/s. ETA: ${etaStr}.${impactStr}`,
                severity,
                metadata: {
                    speed: cme.speed,
                    eta: etaStr,
                    dbm: !!dbmEvent,
                    g_scale: dbmEvent?.impact?.g_scale,
                },
            };
        },
    },

    // ── Satellite Pass (ISS by default) ──────────────────────────────────────
    {
        key: 'notify_sat_pass',
        type: 'pass',
        tier: 'basic',
        source: 'weather',  // evaluated on weather poll cycle (not every 60s swpc tick)
        evaluate(_state, _prefs, ctx) {
            // Satellite pass prediction requires TLE data + SGP4 propagation.
            // For Phase 2, we provide a stub that will be wired to the Rust SGP4
            // module in a future phase. The architecture is ready; the evaluate
            // function will be filled in when the pass prediction service is built.
            // For now, this returns null (no-op).
            return null;
        },
    },

    // ── Radio Blackout (advanced) ────────────────────────────────────────────
    {
        key: 'notify_radio_blackout',
        type: 'flare',
        tier: 'advanced',
        source: 'earth-forecast',
        evaluate(_state, prefs, ctx) {
            const ef = ctx.earthForecast;
            if (!ef) return null;
            const r = ef.radio?.r_scale ?? 0;
            const threshold = prefs.radio_r_threshold ?? 2;
            if (r < threshold) return null;
            return {
                fire: true,
                title: `R${r} Radio Blackout`,
                body: `${ef.radio.desc} X-ray: ${ef.radio.xray_class}-class.`,
                severity: r >= 4 ? 'critical' : r >= 3 ? 'critical' : 'warning',
                metadata: { r_scale: r, xray_class: ef.radio.xray_class, threshold },
            };
        },
    },

    // ── GPS Degradation (advanced) ───────────────────────────────────────────
    {
        key: 'notify_gps',
        type: 'storm',
        tier: 'advanced',
        source: 'earth-forecast',
        evaluate(_state, prefs, ctx) {
            const ef = ctx.earthForecast;
            if (!ef) return null;
            const gnss = ef.gnss;
            const threshold = prefs.gnss_risk_threshold ?? 2;
            if (gnss.level < threshold) return null;
            const loc = ctx.location ?? loadUserLocation() ?? auth.getUser()?.location;
            const city  = loc?.city;
            const label = loc?.label ?? city;
            return {
                fire: true,
                title: `GNSS Risk${label ? ' — ' + label : ''}: ${gnss.label}`,
                body: `${gnss.desc} L1 range delay: ${gnss.range_delay_m} m.${city ? ' (' + city + ')' : ''}`,
                severity: gnss.level >= 3 ? 'critical' : 'warning',
                metadata: { level: gnss.level, range_delay_m: gnss.range_delay_m, threshold, location_id: loc?.id },
            };
        },
    },

    // ── Power Grid Risk (advanced) ───────────────────────────────────────────
    {
        key: 'notify_power_grid',
        type: 'storm',
        tier: 'advanced',
        source: 'earth-forecast',
        evaluate(_state, prefs, ctx) {
            const ef = ctx.earthForecast;
            if (!ef) return null;
            const grid = ef.infrastructure?.powerGrid;
            const sat  = ef.infrastructure?.satellite;
            const g    = ef.timing?.current_g ?? 0;
            const threshold = prefs.power_grid_g_threshold ?? 4;
            if (g < threshold && grid.level < 2) return null;
            const loc = ctx.location ?? loadUserLocation() ?? auth.getUser()?.location;
            const lat = Math.abs(loc?.lat ?? 45);
            const label = loc?.label ?? loc?.city;
            return {
                fire: true,
                title: `G${g} Power Grid Risk${label ? ' — ' + label : ''}`,
                body: `${grid.desc}${sat.level >= 2 ? ' Satellite environment: ' + sat.desc : ''}`,
                severity: g >= 4 ? 'critical' : 'warning',
                metadata: { g_scale: g, grid_level: grid.level, sat_level: sat.level, lat, threshold, location_id: loc?.id },
            };
        },
    },

    // ── Ionospheric Disturbance (advanced) ──────────────────────────────────
    {
        key: 'notify_iono_disturbance',
        type: 'storm',
        tier: 'advanced',
        source: 'earth-forecast',
        evaluate(_state, _prefs, ctx) {
            const ef = ctx.earthForecast;
            if (!ef) return null;
            const iono = ef.ionosphere;
            if (!iono?.disturbed) return null;

            // Build a detailed body from layer statuses
            const parts = [];
            const dl = iono.layers?.dLayer;
            if (dl && dl.status !== 'NORMAL') parts.push(`D-layer: ${dl.desc}`);
            const el = iono.layers?.eLayer;
            if (el && el.status !== 'NORMAL') parts.push(`E-layer: ${el.desc}`);
            const f2 = iono.layers?.f2Layer;
            if (f2 && f2.status !== 'NORMAL') parts.push(`F2-layer: ${f2.desc}`);
            const tec = iono.layers?.tec;
            if (tec && tec.status !== 'NORMAL') parts.push(`TEC: ${tec.desc}`);

            const isBlackout = dl?.status === 'BLACKOUT';

            return {
                fire: true,
                title: isBlackout ? 'Ionospheric Blackout' : 'Ionospheric Disturbance',
                body: parts.length
                    ? parts.join(' ')
                    : iono.summary,
                severity: isBlackout ? 'critical' : 'warning',
                metadata: {
                    d_layer: dl?.status,
                    e_layer: el?.status,
                    f2_layer: f2?.status,
                    tec: tec?.value,
                },
            };
        },
    },

    // ── 27-Day Carrington Recurrence (advanced) ──────────────────────────────
    {
        key: 'notify_recurrence',
        type: 'storm',
        tier: 'advanced',
        source: 'swpc',
        _lastSignal: 'none',
        evaluate(state, _prefs, ctx) {
            // Uses the ImpactScoreEngine's recurrence data if available
            // Listens for impact-score-update events cached by the alert engine
            const recurrence = ctx.recurrence;
            if (!recurrence || recurrence.signal === 'none') {
                this._lastSignal = 'none';
                return null;
            }
            // Only fire when signal strengthens (not on every tick)
            if (recurrence.signal === this._lastSignal) return null;
            const wasWeaker = this._lastSignal === 'none' ||
                (this._lastSignal === 'weak' && recurrence.signal !== 'weak') ||
                (this._lastSignal === 'moderate' && recurrence.signal === 'strong');
            this._lastSignal = recurrence.signal;
            if (!wasWeaker) return null;

            return {
                fire: true,
                title: '27-Day Recurrence Detected',
                body: `${recurrence.signal.charAt(0).toUpperCase() + recurrence.signal.slice(1)} 27-day Carrington recurrence signal detected (r=${recurrence.corr27}). Active region may return to Earth-facing position within 3–5 days — elevated storm risk.`,
                severity: recurrence.signal === 'strong' ? 'warning' : 'info',
                metadata: { corr27: recurrence.corr27, corr54: recurrence.corr54, signal: recurrence.signal },
            };
        },
    },

    // ── Satellite Collision (advanced) ───────────────────────────────────────
    // This alert is triggered by 'conjunction-alert' events from ConjunctionMonitor,
    // not by swpc-update. It's handled specially in AlertEngine._onConjunction().
    {
        key: 'notify_collision',
        type: 'conjunction',
        tier: 'advanced',
        source: 'conjunction',  // special source — handled by separate listener
        evaluate() { return null; },  // no-op — _onConjunction() handles it directly
    },
];

// ─────────────────────────────────────────────────────────────────────────────
//  AlertEngine
// ─────────────────────────────────────────────────────────────────────────────

export class AlertEngine {
    constructor() {
        /**
         * Cooldown tracker. Key is `${alertKey}@${locationId}` so the same
         * alert type can fire independently for different saved locations.
         * @type {Map<string, number>}
         */
        this._cooldowns = new Map();

        /** @type {Array<object>} recent alerts (in-memory for bell UI, newest first) */
        this.recent = [];

        /** Max recent alerts to keep in memory */
        this._maxRecent = 50;

        /** Supabase client (lazy) */
        this._sb = null;

        /** @type {Map<string, object>} weather cache keyed by "lat,lon" */
        this._weatherByKey = new Map();

        /** Cached CME propagation events */
        this._cmeEvents = [];

        /** Weather polling timer */
        this._weatherTimer = null;

        /** Last SWPC state (for weather-triggered re-evaluation) */
        this._lastSwpcState = null;

        /** Cached recurrence data from impact-score-update */
        this._recurrence = null;

        /** Cached earth-forecast data from earth-forecast-update */
        this._earthForecast = null;

        /** Conjunction monitor (advanced tier only) */
        this._conjMonitor = null;

        /** @type {Array<object>} resolved alert locations (saved + fallback) */
        this._locations = [];

        /** Unsubscribe handle for saved-locations change events */
        this._unsubLocations = null;

        this._onSwpc          = this._onSwpc.bind(this);
        this._onCme           = this._onCme.bind(this);
        this._onImpactScore   = this._onImpactScore.bind(this);
        this._onConjunction   = this._onConjunction.bind(this);
        this._onEarthForecast = this._onEarthForecast.bind(this);
        this._onUserLoc       = this._onUserLoc.bind(this);
        this._onLocationsChg  = this._onLocationsChg.bind(this);
    }

    /** Start listening to events and polling weather. */
    start() {
        window.addEventListener('swpc-update', this._onSwpc);
        window.addEventListener('cme-propagation-update', this._onCme);
        window.addEventListener('impact-score-update', this._onImpactScore);
        window.addEventListener('conjunction-alert', this._onConjunction);
        window.addEventListener('earth-forecast-update', this._onEarthForecast);
        window.addEventListener('user-location-changed', this._onUserLoc);
        this._unsubLocations = onLocationsChanged(this._onLocationsChg);
        this._loadRecentFromDB();
        this._refreshLocations().then(() => this._pollWeather());
        this._weatherTimer = setInterval(() => this._pollWeather(), WEATHER_POLL_MS);

        // Start conjunction monitor for advanced users
        if (auth.canUseAdvancedAlerts()) {
            this._conjMonitor = new ConjunctionMonitor().start();
        }

        return this;
    }

    stop() {
        window.removeEventListener('swpc-update', this._onSwpc);
        window.removeEventListener('cme-propagation-update', this._onCme);
        window.removeEventListener('impact-score-update', this._onImpactScore);
        window.removeEventListener('conjunction-alert', this._onConjunction);
        window.removeEventListener('earth-forecast-update', this._onEarthForecast);
        window.removeEventListener('user-location-changed', this._onUserLoc);
        this._unsubLocations?.();
        clearInterval(this._weatherTimer);
        this._conjMonitor?.stop();
    }

    // ── Location resolution ─────────────────────────────────────────────────
    /**
     * Build the list of locations alerts should evaluate against.
     *  - If the user has saved locations: use all with notify_enabled = true.
     *  - Otherwise: fall back to the single localStorage / profile location
     *    so the engine behaves unchanged for users who never used the
     *    Saved Locations card.
     *  - If still nothing: return [null] so alerts without location context
     *    (CME, flare, storm, recurrence) still fire generically.
     */
    async _refreshLocations() {
        const saved = await listLocations({ force: true });
        const active = (saved ?? []).filter(s => s.notify_enabled !== false);
        if (active.length) {
            this._locations = active.map(r => ({
                id:                 r.id,
                label:              r.label,
                lat:                r.lat,
                lon:                r.lon,
                city:               r.city,
                is_primary:         !!r.is_primary,
                alert_config:       r.alert_config ?? {},
                email_enabled:      r.email_alerts_enabled !== false,
            }));
            return;
        }
        const fallback = loadUserLocation() ?? auth.getUser()?.location;
        if (fallback?.lat != null && fallback?.lon != null) {
            this._locations = [{
                id:            null,
                label:         fallback.city ?? 'Your location',
                lat:           fallback.lat,
                lon:           fallback.lon,
                city:          fallback.city,
                is_primary:    true,
                alert_config:  {},
                email_enabled: true,
            }];
        } else {
            this._locations = [null];
        }
    }

    _onUserLoc()       { this._refreshLocations().then(() => this._pollWeather()); }
    _onLocationsChg()  { this._refreshLocations().then(() => this._pollWeather()); }

    /** Get unread count. */
    getUnreadCount() {
        return this.recent.filter(a => !a.read).length;
    }

    /** Mark an alert as read by id. */
    markRead(alertId) {
        const alert = this.recent.find(a => a.id === alertId);
        if (alert) alert.read = true;
        this._markReadInDB(alertId);
        this._dispatch();
    }

    /** Mark all as read. */
    markAllRead() {
        this.recent.forEach(a => { a.read = true; });
        this._markAllReadInDB();
        this._dispatch();
    }

    // ── Private ──────────────────────────────────────────────────────────────

    _onCme(ev) {
        this._cmeEvents = ev.detail?.events ?? [];
    }

    _onImpactScore(ev) {
        // Cache recurrence data for the 27-day recurrence alert
        this._recurrence = ev.detail?.d7?.recurrence ?? null;
    }

    _onEarthForecast(ev) {
        this._earthForecast = ev.detail ?? null;
        // Evaluate earth-forecast-source alerts whenever the forecast updates
        if (auth.isSignedIn() && auth.canUseAlerts()) {
            this._evaluateAllLocations(this._lastSwpcState ?? {}, 'earth-forecast');
        }
    }

    _onConjunction(ev) {
        // Conjunction alert — fired by ConjunctionMonitor
        if (!auth.isSignedIn() || !auth.canUseAdvancedAlerts()) return;
        const prefs = auth.getAlertPrefs();
        if (!prefs.notify_collision) return;

        const c = ev.detail;
        if (!c) return;

        const riskLevel = c.dist_km < 1 ? 'critical' : c.dist_km < 5 ? 'critical' : c.dist_km < 10 ? 'warning' : 'info';
        const etaStr = c.hours_ahead < 1
            ? `${Math.round(c.hours_ahead * 60)} minutes`
            : c.hours_ahead < 24
                ? `${c.hours_ahead.toFixed(1)} hours`
                : `${(c.hours_ahead / 24).toFixed(1)} days`;

        const alert = {
            id: `notify_collision_${Date.now()}`,
            alert_type: 'conjunction',
            severity: riskLevel,
            title: 'Satellite Close Approach',
            body: `${c.target_name} — ${c.dist_km.toFixed(1)} km miss distance with ${c.chaser_name} in ${etaStr}. Threshold: ${c.threshold_km} km.`,
            metadata: {
                target: c.target_name,
                target_norad: c.target_norad,
                chaser: c.chaser_name,
                chaser_norad: c.chaser_norad,
                dist_km: c.dist_km,
                hours_ahead: c.hours_ahead,
            },
            read: false,
            created_at: new Date().toISOString(),
            _key: 'notify_collision',
        };

        this.recent.unshift(alert);
        if (this.recent.length > this._maxRecent) this.recent.pop();
        this._writeAlertToDB(alert);
        this._sendEmail(alert);
        this._dispatch(alert);
        console.info(`[AlertEngine] Fired: ${alert.title} — ${c.dist_km.toFixed(1)} km`);
    }

    _onSwpc(ev) {
        if (!auth.isSignedIn() || !auth.canUseAlerts()) return;
        this._lastSwpcState = ev.detail;
        this._evaluateAllLocations(ev.detail, 'swpc');
    }

    /**
     * Fetch weather for each active location (unique by lat,lon) and
     * evaluate weather-triggered alerts per location.
     */
    async _pollWeather() {
        if (!auth.isSignedIn() || !auth.canUseAlerts()) return;
        if (!this._locations.length) return;

        const seen = new Set();
        for (const loc of this._locations) {
            if (!loc?.lat || !loc?.lon) continue;
            const key = `${loc.lat.toFixed(3)},${loc.lon.toFixed(3)}`;
            if (seen.has(key)) continue;
            seen.add(key);
            const w = await fetchPointWeather(loc.lat, loc.lon);
            if (w) this._weatherByKey.set(key, w);
        }
        // Evaluate weather-triggered alerts across all locations
        this._evaluateAllLocations(this._lastSwpcState ?? {}, 'weather');
    }

    /** Iterate over every active location and evaluate matching alert defs. */
    _evaluateAllLocations(state, source) {
        const basePrefs  = auth.getAlertPrefs();
        const isAdvanced = auth.canUseAdvancedAlerts();
        const now = Date.now();

        // Always evaluate at least once, even without a concrete location,
        // so sources like 'swpc' / 'earth-forecast' that don't strictly need
        // a location (generic storm/flare/CME) still fire.
        const locs = this._locations.length ? this._locations : [null];

        for (const loc of locs) {
            const prefs = loc ? effectivePrefs(loc, basePrefs) : basePrefs;
            const cooldownMs = (prefs.alert_cooldown_min ?? 60) * 60_000;

            // Per-location weather lookup
            const wKey = loc?.lat != null ? `${loc.lat.toFixed(3)},${loc.lon.toFixed(3)}` : null;
            const weather = wKey ? this._weatherByKey.get(wKey) : null;

            const ctx = {
                weather,
                cmeEvents:      this._cmeEvents,
                recurrence:     this._recurrence,
                earthForecast:  this._earthForecast,
                location:       loc,
            };

            for (const def of ALERT_DEFS) {
                if (def.source && def.source !== source) continue;
                if (def.tier === 'advanced' && !isAdvanced) continue;
                if (!prefs[def.key]) continue;

                const cooldownKey = `${def.key}@${loc?.id ?? 'global'}`;
                const lastFire = this._cooldowns.get(cooldownKey) ?? 0;
                if (now - lastFire < cooldownMs) continue;

                let result;
                try {
                    result = def.evaluate(state, prefs, ctx);
                } catch (e) {
                    console.warn(`[AlertEngine] Error evaluating ${def.key} @ ${loc?.label ?? 'global'}:`, e.message);
                    continue;
                }
                if (!result?.fire) continue;

                const alert = {
                    id: `${def.key}_${loc?.id ?? 'global'}_${now}`,
                    alert_type: def.type,
                    severity: result.severity ?? 'info',
                    title: result.title,
                    body: result.body,
                    metadata: {
                        ...(result.metadata ?? {}),
                        location_id:    loc?.id ?? null,
                        location_label: loc?.label ?? null,
                    },
                    read: false,
                    created_at: new Date().toISOString(),
                    _key: def.key,
                    _loc: loc,
                };

                this._cooldowns.set(cooldownKey, now);
                this.recent.unshift(alert);
                if (this.recent.length > this._maxRecent) this.recent.pop();

                this._writeAlertToDB(alert);
                this._sendEmail(alert);
                this._dispatch(alert);

                console.info(`[AlertEngine] Fired: ${alert.title}`);
            }
        }
    }

    _dispatch(newAlert = null) {
        window.dispatchEvent(new CustomEvent('user-alert', {
            detail: {
                alert: newAlert,
                recent: this.recent,
                unread: this.getUnreadCount(),
            },
        }));
    }

    async _getSb() {
        if (this._sb) return this._sb;
        if (!isConfigured()) return null;
        try { this._sb = await getSupabase(); } catch (_) {}
        return this._sb;
    }

    async _writeAlertToDB(alert) {
        const sb = await this._getSb();
        if (!sb) return;
        const userId = auth.getUser()?.id;
        if (!userId) return;
        try {
            await sb.from('alert_history').insert({
                user_id: userId,
                alert_type: alert.alert_type,
                severity: alert.severity,
                title: alert.title,
                body: alert.body,
                metadata: alert.metadata,
                read: false,
            });
        } catch (e) {
            console.warn('[AlertEngine] DB write failed:', e.message);
        }
    }

    /**
     * Send alert email via /api/alerts/email edge function.
     * Only sends if:
     *   - user has email_alerts enabled globally, AND
     *   - the firing location has email_alerts_enabled !== false, AND
     *   - severity meets the user's minimum severity floor.
     */
    async _sendEmail(alert) {
        const prefs = auth.getAlertPrefs();
        if (!prefs.email_alerts) return;

        // Per-location email opt-out
        if (alert._loc && alert._loc.email_enabled === false) return;

        // Check minimum severity filter
        const minSev = prefs.email_min_severity ?? 'warning';
        const sevOrder = { info: 0, warning: 1, critical: 2 };
        if ((sevOrder[alert.severity] ?? 0) < (sevOrder[minSev] ?? 1)) return;

        // Get Supabase JWT for authentication
        const sb = await this._getSb();
        if (!sb) return;
        let token;
        try {
            const { data } = await sb.auth.getSession();
            token = data?.session?.access_token;
        } catch { return; }
        if (!token) return;

        try {
            const res = await fetch('/api/alerts/email', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`,
                },
                body: JSON.stringify({
                    title:          alert.title,
                    body:           alert.body,
                    severity:       alert.severity,
                    alert_type:     alert.alert_type,
                    location_label: alert._loc?.label ?? null,
                    location_city:  alert._loc?.city  ?? null,
                }),
            });
            if (res.ok) {
                console.debug('[AlertEngine] Email sent for:', alert.title);
            } else {
                const err = await res.json().catch(() => ({}));
                if (err.error !== 'not_configured') {
                    console.warn('[AlertEngine] Email failed:', err.error, err.detail);
                }
            }
        } catch (e) {
            console.debug('[AlertEngine] Email send error:', e.message);
        }
    }

    async _loadRecentFromDB() {
        const sb = await this._getSb();
        if (!sb) return;
        const userId = auth.getUser()?.id;
        if (!userId) return;
        try {
            const { data } = await sb
                .from('alert_history')
                .select('id, alert_type, severity, title, body, metadata, read, created_at')
                .eq('user_id', userId)
                .order('created_at', { ascending: false })
                .limit(this._maxRecent);
            if (data?.length) {
                this.recent = data;
                this._dispatch();
            }
        } catch (e) {
            console.warn('[AlertEngine] DB load failed:', e.message);
        }
    }

    async _markReadInDB(alertId) {
        const sb = await this._getSb();
        if (!sb) return;
        try {
            if (alertId?.length === 36 && alertId.includes('-')) {
                await sb.from('alert_history').update({ read: true }).eq('id', alertId);
            }
        } catch (_) {}
    }

    async _markAllReadInDB() {
        const sb = await this._getSb();
        if (!sb) return;
        const userId = auth.getUser()?.id;
        if (!userId) return;
        try {
            await sb.from('alert_history').update({ read: true }).eq('user_id', userId).eq('read', false);
        } catch (_) {}
    }
}
