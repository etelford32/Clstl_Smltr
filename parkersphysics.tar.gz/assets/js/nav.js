/**
 * nav.js — Shared navigation component with rich dropdowns + tier gating
 *
 * Generates a full navigation bar with:
 *   - Logo + brand
 *   - Dropdown menus: Earth, Space Weather, Stars, Black Holes, Simulators
 *   - Tier-gated items (public, free, advanced) where 'advanced' ≡ PRO
 *     (Advanced + Institution + Enterprise). See auth.isPro().
 *   - Auth state (Sign In / Dashboard / Admin badge)
 *   - Compact utility text-links in the auth area (Dashboard · Account ·
 *     Pricing) plus an inline PRO promo for non-pro users.
 *   - Mobile burger with full menu expansion + accordion dropdowns
 *   - Robust hover with delay for desktop, touch-aware for hybrid devices
 *   - Keyboard support (Escape, Tab focus management)
 */

// Side-effect import: OAuth/OTP misland sentinel. Runs first so a token that
// landed on the wrong page (Supabase Site-URL fallback) is detected + forwarded
// to /auth-callback.html before anything else can consume or clear the hash.
// See js/oauth-sentinel.js.
import './oauth-sentinel.js';

// Side-effect import: cross-page guided tour controller. Hooks the hero CTA
// on the home page and renders a progress banner on each tour stop.
import './explore-tour.js';
import { tierLevel as _cfgTierLevel, PAID_PLAN_IDS } from './tier-config.js';
// Side-effect import: boots the telemetry singleton (window.onerror,
// unhandledrejection, Web-Vitals observers). Every page that mounts
// the nav gets autocapture for free; pages without the nav (rare,
// embedded simulators) opt-in by importing js/telemetry.js directly.
import './telemetry.js';

// Root-absolute so the shared nav renders identically from any directory
// depth — pages under /satellite-operator/ etc. would otherwise 404 the
// logo and every nav link (relative paths resolve against the subdir).
const LOGO_IMG = '/ParkersPhysics_logo2.jpg';

// ── Navigation Structure ─────────────────────────────────────────────────────

const NAV_DROPDOWNS = [
    {
        label: 'Earth',
        id: 'earth-menu',
        items: [
            { href: 'earth.html',             label: 'Earth Weather',       sub: 'Predictive weather + magnetosphere',   tier: 'public',   icon: '🌍' },
            { href: 'moon.html',              label: 'Moon',                sub: 'Lunar radiation environment',          tier: 'public',   icon: '🌙' },
            { href: 'operations.html',        label: 'Operations',          sub: 'Fleet & debris analysis console',      tier: 'public',   icon: '🛰️', badge: 'PRO PREVIEW', id: 'operations' },
            { href: 'satellites.html',        label: 'Satellites',          sub: 'Real-time orbital tracking',           tier: 'public', icon: '🛰️' },
            { href: 'launch-planner.html',    label: 'Launch Planner',      sub: 'SpaceX/Blue Origin launches + weather', tier: 'public', icon: '🚀', id: 'launch-planner' },
            { href: 'upper-atmosphere.html',  label: 'Upper Atmosphere',    sub: 'Thermosphere + exosphere simulator',    tier: 'public', icon: '🌡️', id: 'upper-atmosphere' },
            { href: 'satellite-designer.html', label: 'Satellite Designer', sub: 'Build a craft · fly drag vs thrust',     tier: 'public', icon: '🛰️', badge: 'NEW', id: 'satellite-designer' },
            { href: 'spaceship-designer.html', label: 'Space Ship Designer', sub: 'Build a rocket · fly it to orbit in 3D', tier: 'public', icon: '🚀', badge: 'NEW', id: 'spaceship-designer' },
        ],
    },
    {
        label: 'Space Weather',
        id: 'space-weather',
        items: [
            { href: 'space-weather.html', label: 'Space Weather',  sub: 'Live solar & geomagnetic data',   tier: 'public', icon: '🌤️', id: 'weather' },
            { href: 'auroracle.html', label: 'AurOracle', sub: 'Predict the aurora · 7-night + 30-day outlook', tier: 'public', icon: '🌌', badge: 'NEW', id: 'auroracle' },
            { href: 'far-side-watch.html', label: 'Far-Side Watch', sub: 'Regions rotating in · days-to-weeks horizon', tier: 'public', icon: '🌗', badge: 'NEW', id: 'far-side-watch' },
            { href: 'gannon-superstorm.html', label: 'Gannon Superstorm', sub: 'May 2024 G5 hindcast · MHD-corrected density', tier: 'public', icon: '⚡', badge: 'NEW', id: 'gannon-superstorm' },
            { href: 'solar-system.html',       label: 'Solar System',   sub: '31 moons · live Galilean N-body', tier: 'public', icon: '🪐', id: 'solar' },
            { href: 'jupiter-system.html', label: 'Jupiter System', sub: 'Galilean moons · 4:2:1 Laplace resonance', tier: 'public', icon: '🪐', id: 'jupiter-system' },
            { href: 'saturn-system.html', label: 'Saturn System', sub: 'Moon-sculpted rings · Cassini Division · live density waves', tier: 'public', icon: '🪐', badge: 'NEW', id: 'saturn-system' },
            { href: 'uranus-system.html', label: 'Uranus System', sub: 'Tipped 98° · ε-ring shepherds · crowded moons', tier: 'public', icon: '🔷', badge: 'NEW', id: 'uranus-system' },
            { href: 'neptune-system.html', label: 'Neptune System', sub: 'Retrograde Triton · rings & arcs · J₂ N-body', tier: 'public', icon: '🔵', badge: 'NEW', id: 'neptune-system' },
            { href: 'sun.html',           label: 'The Sun',        sub: 'Real-time solar surface view',    tier: 'public', icon: '☀️' },
            { href: 'missions.html',      label: 'Space Missions', sub: 'Inner solar system fleet roster', tier: 'public', icon: '🛸', id: 'missions' },
            { href: 'mission-planner.html', label: 'Mission Planner', sub: 'Launch rockets · plan Moon & Mars trips', tier: 'public', icon: '🎯', badge: 'NEW', id: 'mission-planner' },
            { href: 'galactic-map.html',  label: 'Galaxy',         sub: '3D Milky Way star map',           tier: 'free',   icon: '🌌' },
        ],
    },
    {
        label: 'Stars',
        id: 'stars',
        items: [
            { href: 'sirius.html',     label: 'Sirius Binary',    sub: 'A1V + white dwarf system',    tier: 'public', icon: '⭐' },
            { href: 'betelgeuse.html', label: 'Betelgeuse',       sub: 'Red supergiant · M1-2 Ia',    tier: 'public', icon: '🔴' },
            { href: 'vega.html',       label: 'Vega',             sub: 'Rapid rotator · A0V',          tier: 'public', icon: '💫' },
            { href: 'achernar.html',   label: 'Achernar',         sub: 'Oblate Be star · B6Vep',       tier: 'public', icon: '🌀' },
            { href: 'wr102.html',      label: 'WR-102',           sub: 'Wolf-Rayet · hottest known',   tier: 'free',   icon: '🌟' },
            { href: 'sirius-planetary.html',     label: 'Sirius Planetary', sub: '3D stellar system simulator',  tier: 'free',   icon: '🪐' },
        ],
    },
    {
        label: 'Black Holes',
        id: 'black-holes',
        items: [
            { href: 'ton618.html',           label: 'TON 618',             sub: 'Research observatory · 6.6×10¹⁰ M☉', tier: 'public', icon: '🕳️', id: 'ton618' },
            { href: 'abell85.html',          label: 'Abell 85 Pair',       sub: 'Binary inspiral timeline · Gyr dynamics', tier: 'public', icon: '🕳️', badge: 'NEW', id: 'abell85' },
            { href: 'holm15a.html',          label: 'Holm 15A',            sub: 'Merger history · cinematic auto-play',    tier: 'public', icon: '🕳️', badge: 'NEW', id: 'holm15a' },
            { href: 'merger-twins.html',     label: 'Merger Twins',        sub: 'A402 future ↔ Holm 15A past · τ-synced',  tier: 'public', icon: '🕳️', badge: 'NEW', id: 'merger-twins' },
            { href: 'sagittarius.html',      label: 'Sagittarius A*',      sub: 'Galactic center · live',              tier: 'public', icon: '🕳️', id: 'sagittarius' },
            { href: 'black-hole-fluid.html', label: 'Black Hole Accretion', sub: 'Fluid dynamics simulation',          tier: 'public', icon: '🕳️' },
        ],
    },
    {
        label: 'Simulators',
        id: 'simulators',
        items: [
            { href: 'solar-fluid.html',       label: 'Solar Fluid',          sub: 'Navier-Stokes MHD solver',        tier: 'public', icon: '🌊' },
            { href: 'stellar-wind.html',      label: 'Stellar Wind',         sub: 'Parker spiral + wind stream',     tier: 'public', icon: '💨' },
            { href: 'star2d.html',            label: '2D Stellar Modeler',   sub: 'HR diagram + classification',     tier: 'public', icon: '📊' },
            { href: 'star2d-advanced.html',   label: 'Advanced 2D Solar',    sub: 'CME, Parker spirals, fluid',      tier: 'free',   icon: '🔬' },
            { href: 'gravity-lab.html',       label: 'Gravity Lab',          sub: 'Live N-body · moons & resonances', tier: 'public', icon: '🪐', badge: 'NEW', id: 'gravity-lab' },
            { href: 'accretion-disc.html',    label: 'Accretion Disc',       sub: 'α-disc + pebble accretion + Theia → Moon', tier: 'public', icon: '🌀', badge: 'NEW', id: 'accretion-disc' },
            { href: 'time-machine.html',      label: 'Orbital Time Machine', sub: 'N-body propagation · ±10 kyr to ±1 Myr', tier: 'public', icon: '⏳', badge: 'IN DEV', id: 'time-machine' },
            { href: 'rust.html',              label: 'Rust/WASM Engine',     sub: 'WebAssembly compute module',      tier: 'free',   icon: '⚙️' },
        ],
    },
];

// ── Auth helpers ──────────────────────────────────────────────────────────────

const AUTH_KEY = 'pp_auth';

function _getAuth() {
    let auth = null;
    try { auth = JSON.parse(localStorage.getItem(AUTH_KEY) || 'null'); } catch (_) {}
    if (!auth) { try { auth = JSON.parse(sessionStorage.getItem(AUTH_KEY) || 'null'); } catch (_) {} }
    if (!auth?.signedIn) return null;
    // Superadmin "view as user" override (js/view-as.js). Anti-escalation:
    // applyTo() returns the input unchanged unless the real role is
    // 'superadmin' — anyone else who plants the sessionStorage key is
    // ignored. Server-side calls keep using the real session JWT.
    try {
        const raw = sessionStorage.getItem('pp-view-as');
        if (raw && auth.role === 'superadmin') {
            const o = JSON.parse(raw);
            if (o && o.role) {
                return { ...auth, role: o.role, plan: o.plan ?? auth.plan, _viewAs: true, _realRole: 'superadmin' };
            }
        }
    } catch (_) {}
    return auth;
}

// Tier level determines which menu items + features a user can see.
// Educator sits alongside Basic (level 2) — same data feeds, plus embed
// permission. Institution + Enterprise are Advanced-equivalent (level 3).
// The mapping itself lives in js/tier-config.js (single source of truth);
// this wrapper keeps the existing 0 fallback for blank-plan accounts.
function _tierLevel(plan, role) {
    const lvl = _cfgTierLevel(plan, role);
    return lvl > 0 ? lvl : 0;
}

function _tierRequired(tier) {
    if (tier === 'advanced') return 3;
    if (tier === 'intro') return 2;
    if (tier === 'free') return 1;
    return 0;
}

// ── Global-listener guard ──────────────────────────────────────────────────
// initNav() is called once on import and again on every `auth-changed`
// event (so the admin badge / sign-in state stays fresh). Without this
// guard each re-entry would stack ANOTHER copy of the document/window
// event listeners — the earliest ones then reference stale burger/menu
// DOM nodes (nav.innerHTML = html blows them away on every build), which
// on mobile produced the "can't re-toggle the burger" bug: the original
// click handler was wired to a now-detached element.
//
// We bind once, then always resolve burger/menu via document.getElementById
// so we're operating on the live DOM regardless of how many re-renders
// have happened.
let _globalListenersBound = false;

function _getBurger() { return document.getElementById('nav-burger'); }
function _getMenu()   { return document.getElementById('nav-menu');  }

function _closeAll() {
    const menu = _getMenu();
    const burger = _getBurger();
    menu?.classList.remove('open');
    burger?.classList.remove('open');
    burger?.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    document.querySelectorAll('nav .nav-drop.open').forEach(d => {
        d.classList.remove('open');
        d.querySelector('.nav-drop-btn')?.setAttribute('aria-expanded', 'false');
    });
}

// ── Nav Builder ──────────────────────────────────────────────────────────────

export function initNav(activeId = '') {
    const nav = document.querySelector('nav');
    if (!nav) return;

    // Lazy-load the cookie-consent banner — module ensures single-mount.
    if (!window._ppConsentLoaded) {
        window._ppConsentLoaded = true;
        import('./cookie-consent.js').catch(() => { window._ppConsentLoaded = false; });
    }

    // Lazy-load the "View as user" widget (superadmin-only; self-gates).
    // Real-role check happens inside view-as.js — non-superadmins get nothing.
    if (!window._ppViewAsLoaded) {
        window._ppViewAsLoaded = true;
        import('./view-as.js').then(m => m.mount?.()).catch(() => { window._ppViewAsLoaded = false; });
    }

    const auth = _getAuth();
    const userTier = _tierLevel(auth?.plan, auth?.role);
    const isSignedIn = !!auth;
    const isAdmin = auth?.role === 'admin' || auth?.role === 'superadmin';

    // Educator tier carries a "Powered by Parkers Physics" attribution
    // requirement. Mount the badge once; it self-renders on auth-changed
    // so a plan switch toggles visibility without a reload. Cheap to
    // import even when no badge is shown — the module is ~1.5kb.
    import('./attribution-badge.js')
        .then(m => m.mountAttributionBadge?.())
        .catch(() => { /* nav must not break if the badge module fails */ });

    // First-party analytics: auto-tracks page views, time-on-page, scroll
    // depth, and (opt-in) clicks. Side-effect import — singleton inside.
    //
    // Shared identify bootstrap: identify() was previously only wired into
    // the auth pages (signin/signup/auth-callback/settings/welcome), so a
    // returning user landing straight on an app page never tagged their
    // analytics_events rows with a user_id. The admin "unique users" KPIs
    // filter out null user_id, so they read 0 despite real traffic. nav.js
    // loads on every page and re-runs on `auth-changed`, so this is the
    // single place that reliably knows "who is signed in, on every page".
    // Guarded on the user id so re-renders don't spam identify()/heartbeat;
    // a sign-out (auth → null) resets the guard so a later sign-in
    // re-identifies.
    import('./analytics.js')
        .then(m => {
            const uid = auth?.id;
            if (uid && window._ppAnalyticsIdentified !== uid) {
                window._ppAnalyticsIdentified = uid;
                m.analytics?.identify?.(uid, { plan: auth.plan, role: auth.role });
            } else if (!uid) {
                window._ppAnalyticsIdentified = null;
            }
        })
        .catch(() => { /* analytics must not break nav */ });

    // Re-render nav when profile fetches real role (fixes admin button
    // not showing because nav rendered before fetchProfile() resolved)
    if (!nav._authListener) {
        nav._authListener = true;
        window.addEventListener('auth-changed', () => initNav(activeId));
    }

    let html = `
        <a href="/index.html" class="nav-brand" aria-label="Parkers Physics home">
            <img src="${LOGO_IMG}" class="nav-logo-img" alt="Parkers Physics">
            Parkers Physics
        </a>
        <button type="button" class="nav-burger" id="nav-burger" aria-label="Menu" aria-expanded="false">
            <span class="burger-line"></span>
            <span class="burger-line"></span>
            <span class="burger-line"></span>
        </button>
        <div class="nav-menu" id="nav-menu">
    `;

    // Home link
    html += `<a href="/index.html" class="nav-item${activeId === 'home' ? ' active' : ''}">Home</a>`;

    // Dropdown menus
    for (const dd of NAV_DROPDOWNS) {
        const anyActive = dd.items.some(i => {
            if (i.section) return false;
            const itemId = i.id || i.href.replace('.html', '');
            return itemId === activeId || itemId.startsWith(activeId) || activeId.startsWith(itemId);
        });

        html += `<div class="nav-drop">`;
        html += `<button class="nav-drop-btn${anyActive ? ' active' : ''}" aria-haspopup="true" aria-expanded="false">${dd.label} <span class="nav-caret">&#9662;</span></button>`;
        html += `<div class="nav-drop-menu" role="menu">`;

        for (const item of dd.items) {
            if (item.section) {
                html += `<div class="nav-drop-section">${item.section}</div>`;
                continue;
            }

            const required = _tierRequired(item.tier);
            const hasAccess = userTier >= required || item.tier === 'public';

            if (!hasAccess && item.tier === 'advanced') {
                html += `<a href="/pricing.html" class="nav-drop-link" style="opacity:0.5" role="menuitem" title="Available on Advanced plan">
                    <span class="ndl-icon">${item.icon || ''}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label} <span class="nav-badge-pro">PRO</span></span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            } else if (!hasAccess) {
                html += `<a href="/signin.html" class="nav-drop-link" style="opacity:0.4" role="menuitem" title="Sign up for free to access">
                    <span class="ndl-icon">${item.icon || ''}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label} <span style="font-size:.6rem;color:#665">Sign up</span></span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            } else {
                const _hid = item.id || item.href.replace('.html','');
                const _isAct = _hid === activeId || _hid.startsWith(activeId) || activeId.startsWith(_hid);
                html += `<a href="/${item.href}" class="nav-drop-link${_isAct ? ' active' : ''}" role="menuitem">
                    <span class="ndl-icon">${item.icon || ''}</span>
                    <span class="ndl-body">
                        <span class="ndl-title">${item.label}${item.badge ? (
                            item.badge === 'NEW'
                                ? ` <sup class="nav-badge-new">${item.badge}</sup>`
                                : ` <span class="nav-badge-pro" style="background:rgba(0,200,200,.12);color:#0cc;border-color:rgba(0,200,200,.25)">${item.badge}</span>`
                        ) : ''}</span>
                        <span class="ndl-sub">${item.sub}</span>
                    </span>
                </a>`;
            }
        }

        html += `</div></div>`;
    }

    // Spacer + auth
    html += '<span class="nav-spacer"></span>';

    // Utility text-links (Dashboard · Account · Pricing) + PRO promo.
    // Signed-out users only get Pricing (Dashboard/Account require auth).
    // The PRO promo nudges Free/Basic users toward the simulations
    // unlocked by Advanced: Satellites, Launch Planner, Upper Atmosphere.
    const isPro = userTier >= 3;
    html += `<div class="nav-utility-links">`;
    if (isSignedIn) {
        html += `<a href="/dashboard.html" class="nav-util-link">Dashboard</a>`;
        html += `<a href="/account.html" class="nav-util-link">Account</a>`;
    }
    html += `<a href="/pricing.html" class="nav-util-link">Pricing</a>`;
    if (!isPro) {
        html += `<a href="/pricing.html" class="nav-pro-promo" title="Unlock Satellites, Launch Planner & Upper Atmosphere with PRO">
            <span class="nav-pro-spark">✨</span><span class="nav-pro-text">PRO unlocks Satellites · Launch Planner · Upper Atmosphere</span><span class="nav-pro-arrow" aria-hidden="true">→</span>
        </a>`;
    }
    html += `</div>`;

    html += '<span class="nav-auth-sep"></span>';

    if (isSignedIn) {
        // Notification bell (any paid tier or admin). PAID_PLAN_IDS is the
        // canonical set from js/tier-config.js.
        const canAlert = PAID_PLAN_IDS.has(auth?.plan) || isAdmin;
        if (canAlert) {
            html += `<div class="nav-bell-wrap" id="nav-bell-wrap">
                <button class="nav-bell" id="nav-bell-btn" title="Alerts" aria-label="Notifications">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                    </svg>
                    <span class="nav-bell-badge" id="nav-bell-badge" style="display:none">0</span>
                </button>
                <div class="nav-bell-dropdown" id="nav-bell-dropdown" style="display:none">
                    <div class="nav-bell-header">
                        <span style="font-weight:700;font-size:.82rem;color:#ccc">Alerts</span>
                        <button id="nav-bell-read-all" style="background:none;border:none;color:var(--accent,#0cf);cursor:pointer;font-size:.68rem;font-family:inherit">Mark all read</button>
                    </div>
                    <div class="nav-bell-list" id="nav-bell-list">
                        <div style="padding:20px;text-align:center;color:#556;font-size:.78rem">No alerts yet</div>
                    </div>
                    <a href="/dashboard.html" class="nav-bell-footer">View all alerts</a>
                </div>
            </div>`;
        }
        if (auth?.role === 'tester') {
            html += `<span class="nav-item" style="background:rgba(0,200,200,.12);color:#0cc;border-color:rgba(0,200,200,.25);font-weight:700;font-size:.7rem;cursor:default">TESTER</span>`;
        }
        if (isAdmin) {
            html += `<a href="/admin.html" class="nav-item nav-admin-link">${auth.role === 'superadmin' ? 'SUPER' : 'ADMIN'}</a>`;
        }
        html += `<button class="nav-item nav-signout" id="nav-signout-btn">Sign Out</button>`;
    } else {
        html += `<a href="/signin.html" class="nav-item nav-login">Sign In</a>`;
        html += `<a href="/signup.html" class="nav-item nav-signup">Sign Up Free</a>`;
    }

    html += '</div>';
    nav.innerHTML = html;

    // ── Event handlers ────────────────────────────────────────────────────

    // ── Per-render, bound to the FRESH burger/menu DOM nodes ──────────────
    // These two listeners live on elements that were just created by
    // `nav.innerHTML = html`, so each initNav re-entry gets them anew
    // without any stale references. The globally-bound listeners below
    // always look up the live DOM by id.
    const burger = document.getElementById('nav-burger');
    const menu   = document.getElementById('nav-menu');

    burger?.addEventListener('click', (e) => {
        // stopPropagation keeps the "close on outside click" handler
        // below from firing on the same event bubble path.
        e.stopPropagation();
        const willOpen = !menu.classList.contains('open');
        if (willOpen) {
            menu.classList.add('open');
            burger.classList.add('open');
            burger.setAttribute('aria-expanded', 'true');
            document.body.style.overflow = 'hidden';
        } else {
            _closeAll();
        }
    });

    menu?.addEventListener('click', e => {
        if (e.target.closest('.nav-drop-link') || e.target.closest('.nav-item')) {
            // Only close on mobile — on desktop, dropdown link clicks
            // navigate normally and the menu goes away with the page.
            if (window.innerWidth <= 1024) _closeAll();
        }
    });

    // ── Global listeners — bound ONCE across all initNav re-entries ───────
    if (!_globalListenersBound) {
        _globalListenersBound = true;

        // Track whether last interaction was touch (for hybrid devices).
        // Attached to document (not nav) so the flag survives re-renders.
        document.addEventListener('touchstart', () => {
            document.body.dataset.ppLastWasTouch = 'true';
        }, { passive: true });
        document.addEventListener('mousemove', () => {
            document.body.dataset.ppLastWasTouch = 'false';
        }, { passive: true });

        // Close on outside click.
        document.addEventListener('click', e => {
            if (!e.target.closest('nav')) _closeAll();
        });

        // Escape closes dropdowns and mobile menu.
        document.addEventListener('keydown', e => {
            if (e.key !== 'Escape') return;
            _closeAll();
            const openBtn = document.querySelector('nav .nav-drop.open .nav-drop-btn');
            if (openBtn) openBtn.focus();
            else _getBurger()?.focus();
        });
    }

    // ── Dropdown hover (desktop) + click (touch/mobile) ──────────────────
    nav.querySelectorAll('.nav-drop').forEach(drop => {
        const btn = drop.querySelector('.nav-drop-btn');
        const dropMenu = drop.querySelector('.nav-drop-menu');
        let closeTimer = null;

        function openDrop() {
            clearTimeout(closeTimer);
            // Close sibling dropdowns
            nav.querySelectorAll('.nav-drop.open').forEach(d => {
                if (d !== drop) {
                    d.classList.remove('open');
                    d.querySelector('.nav-drop-btn')?.setAttribute('aria-expanded', 'false');
                }
            });
            drop.classList.add('open');
            btn?.setAttribute('aria-expanded', 'true');
        }

        function scheduleClose() {
            clearTimeout(closeTimer);
            closeTimer = setTimeout(() => {
                drop.classList.remove('open');
                btn?.setAttribute('aria-expanded', 'false');
            }, 250);
        }

        // Desktop: hover with 250ms grace period
        drop.addEventListener('mouseenter', () => {
            if (document.body.dataset.ppLastWasTouch !== 'true') openDrop();
        });
        drop.addEventListener('mouseleave', () => {
            if (document.body.dataset.ppLastWasTouch !== 'true') scheduleClose();
        });

        // Keep open when hovering the dropdown menu itself
        if (dropMenu) {
            dropMenu.addEventListener('mouseenter', () => {
                if (document.body.dataset.ppLastWasTouch !== 'true') clearTimeout(closeTimer);
            });
            dropMenu.addEventListener('mouseleave', () => {
                if (document.body.dataset.ppLastWasTouch !== 'true') scheduleClose();
            });
        }

        // Click/tap toggle — works on all devices
        btn?.addEventListener('click', e => {
            e.stopPropagation();
            e.preventDefault();
            if (drop.classList.contains('open')) {
                drop.classList.remove('open');
                btn.setAttribute('aria-expanded', 'false');
            } else {
                openDrop();
            }
        });
    });

    // Sign out — use auth module to clear Supabase session + local storage
    document.getElementById('nav-signout-btn')?.addEventListener('click', async () => {
        try {
            const { auth } = await import('./auth.js');
            await auth.ready();
            auth.signOut('/index.html');
        } catch (_) {
            // Fallback if auth module fails to load
            try { localStorage.removeItem(AUTH_KEY); } catch (_e) {}
            try { sessionStorage.removeItem(AUTH_KEY); } catch (_e) {}
            window.location.href = '/index.html';
        }
    });

    // ── Notification bell ────────────────────────────────────────────────
    const bellBtn      = document.getElementById('nav-bell-btn');
    const bellDropdown = document.getElementById('nav-bell-dropdown');
    const bellBadge    = document.getElementById('nav-bell-badge');
    const bellList     = document.getElementById('nav-bell-list');

    if (bellBtn && bellDropdown) {
        // Toggle dropdown on click
        bellBtn.addEventListener('click', e => {
            e.stopPropagation();
            const open = bellDropdown.style.display === 'none';
            bellDropdown.style.display = open ? 'block' : 'none';
        });

        // Close on outside click
        document.addEventListener('click', e => {
            if (!e.target.closest('#nav-bell-wrap')) {
                bellDropdown.style.display = 'none';
            }
        });

        // Mark all read
        document.getElementById('nav-bell-read-all')?.addEventListener('click', () => {
            window.dispatchEvent(new CustomEvent('alert-mark-all-read'));
        });

        // Listen for alert updates
        window.addEventListener('user-alert', e => {
            const { recent, unread } = e.detail;
            // Update badge
            if (bellBadge) {
                bellBadge.textContent = unread > 99 ? '99+' : unread;
                bellBadge.style.display = unread > 0 ? '' : 'none';
            }
            // Update list (show last 8)
            if (bellList && recent) {
                if (!recent.length) {
                    bellList.innerHTML = '<div style="padding:20px;text-align:center;color:#556;font-size:.78rem">No alerts yet</div>';
                    return;
                }
                bellList.innerHTML = recent.slice(0, 8).map(a => {
                    const age = _relTime(a.created_at);
                    const sevCol = a.severity === 'critical' ? '#ff4444' : a.severity === 'warning' ? '#ffaa00' : '#44cc88';
                    const readCls = a.read ? ' style="opacity:.5"' : '';
                    return `<div class="nav-bell-item"${readCls}>
                        <span class="nav-bell-dot" style="background:${sevCol}"></span>
                        <div class="nav-bell-content">
                            <div class="nav-bell-title">${_escHtml(a.title)}</div>
                            <div class="nav-bell-body">${_escHtml(a.body?.slice(0, 100) ?? '')}</div>
                            <div class="nav-bell-time">${age}</div>
                        </div>
                    </div>`;
                }).join('');
            }
        });
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function _relTime(isoStr) {
    const ms = Date.now() - new Date(isoStr).getTime();
    if (ms < 60_000) return 'Just now';
    if (ms < 3600_000) return `${Math.floor(ms / 60_000)}m ago`;
    if (ms < 86400_000) return `${Math.floor(ms / 3600_000)}h ago`;
    return `${Math.floor(ms / 86400_000)}d ago`;
}

function _escHtml(s) {
    return s == null ? '' : String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
